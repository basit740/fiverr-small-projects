import React from "react";
import CheckoutForm from "../websiteComponents/CheckoutForm";
const Checkout = () => {
 
  return (
   <CheckoutForm/>
  );
};

export default Checkout;
