import React, { useState } from "react";
import ContactForm from "../websiteComponents/ContactForm";
const Contact = () => {
  return (
    <ContactForm/>
  );
};

export default Contact;
