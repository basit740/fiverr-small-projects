import React from 'react';
import BookRoomForm from '../websiteComponents/BookRoomForm';
const BookRoom = () => {
	return <BookRoomForm />;
};

export default BookRoom;
