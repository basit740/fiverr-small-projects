import React, { useContext } from "react";
import DetailsPagination from "../websiteComponents/DetailsPagination";


const CategoryDetails = () => {
  return(
    <DetailsPagination/>
  );
};

export default CategoryDetails;
