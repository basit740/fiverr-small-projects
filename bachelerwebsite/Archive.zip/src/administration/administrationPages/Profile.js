import React from "react";
import ProfileInfo from "../administrationComponents/ProfileInfo";

const Profile = () => {
  return (
    <>
      <ProfileInfo />
    </>
  );
};

export default Profile;
