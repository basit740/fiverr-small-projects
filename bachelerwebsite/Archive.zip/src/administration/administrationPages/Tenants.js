import React from "react";

import Customers from "../administrationComponents/Customers";
const Tenants = () => {
  return (
    <>
      <Customers />
    </>
  );
};

export default Tenants;
