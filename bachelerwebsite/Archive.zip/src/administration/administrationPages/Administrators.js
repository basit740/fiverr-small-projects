import React from "react";
import Administrator from "../administrationComponents/Administrator";
const Administrators = () => {
  return (
    <>
      <Administrator />
    </>
  );
};

export default Administrators;
