import React from "react";
import CategoryDataComponent from "../administrationComponents/CategoryDataComponent";
const Categories = () => {
  return <CategoryDataComponent />;
};

export default Categories;
