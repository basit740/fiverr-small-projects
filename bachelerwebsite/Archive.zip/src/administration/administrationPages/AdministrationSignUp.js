import React, { useState } from "react";
import Signup from "../administrationComponents/Signup";
const AdministrationSignUp = () => {
  return (
    <div>
      <Signup />
    </div>
  );
};

export default AdministrationSignUp;
