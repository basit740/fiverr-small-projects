import React from 'react';

const Calendar = () => {
	return (
		<>
			<h2>Calandar</h2>
		</>
	);
};

export default Calendar;
